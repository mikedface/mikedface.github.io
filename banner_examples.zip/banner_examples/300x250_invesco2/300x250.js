(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.InvescoDistributorsInc = function() {
	this.initialize(img.InvescoDistributorsInc);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,155,13);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#002179").s().p("AASBJIAAg5IgBgKQgBgGgCgBQgCgEgEgBIgIgBIgHABQgDABgCADQgCACgCAEIgBAMIAAA5IgcAAIAAiDIAcgOIAAAwQADgEAHgDQAHgCAHAAQAKAAAHADQAHAEAFAGQAEAGADAJQADAHgBAMIAAA7g");
	this.shape.setTransform(184.7,13.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#002179").s().p("AgBBIQgEgDgFgEQgDgEgCgGQgCgGAAgGIAAgxIgRAAIAAgaIARAAIAAgbIAbgOIAAApIAZAAIAAAaIgZAAIAAApQAAAHADADQACADAFAAQADAAAEgCIAIgGIgEAcIgJAEQgFACgHAAQgGAAgFgCg");
	this.shape_1.setTransform(174.6,14);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#002179").s().p("AgUA1QgHgDgFgEQgGgGgDgGQgDgIAAgIQAAgJADgHQADgFAGgFQAGgEAIgDQAHgBAJAAQAJAAAKADIAAgEQAAgHgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKAAQAKAAAIACQAIACAFAFQAGAFADAGQADAIAAAIIAABGIgcAAIAAgHQgDAEgGACQgHACgGABQgIAAgHgCgAgNAIQgEADAAAHQAAAFAEAEQAEAFAIgBQAGAAAFgCQAFgDACgFIAAgMQgDgDgEgBIgLgBQgIAAgEAEg");
	this.shape_2.setTransform(165.4,16);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#002179").s().p("AgshGIAbAAIAAAHIAKgHQAGgCAFAAQAJAAAHADQAIAEAFAGQAGAHADALQADAPAAAKQAAAMgDAJQgCAJgGAIQgFAHgHADQgIAEgKAAQgFAAgGgCQgGgCgEgEIAAAfIgbAOgAgJgsQgEACgEAFIAAAmQAEAFAEACQAFACAFAAQAEAAADgBQADgCACgDIADgIIABgLIgBgOIgDgJIgGgGQgDgCgEAAQgFAAgEACg");
	this.shape_3.setTransform(155.5,17.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#002179").s().p("AgBBIQgEgDgFgEQgDgEgCgGQgCgGAAgGIAAgxIgSAAIAAgaIASAAIAAgbIAagOIAAApIAaAAIAAAaIgaAAIAAApQABAHADADQACADAFAAQADAAAEgCIAIgGIgDAcIgJAEQgHACgGAAQgGAAgFgCg");
	this.shape_4.setTransform(139.9,14);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#002179").s().p("AgXAyQgHgCgFgHQgFgGgCgIQgCgKgBgMIAAg5IAcAAIAAA3IABALQABAFACADQACADADABQAEABAEABQAEgBAEgBQADgCADgDQACgCABgFIABgKIAAg4IAbAAIAABoIgbAAIAAgHQgEAEgGACQgHACgHABQgJAAgIgEg");
	this.shape_5.setTransform(130.6,16.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#002179").s().p("AgPAyQgJgDgHgIQgGgHgEgKQgEgKAAgMQAAgLAEgKQAEgKAGgIQAHgHAKgEQAIgDAKAAIANABQAGABAFADIAKAHIAIAKIgSATQgFgIgGgDQgFgEgIAAQgEAAgEACQgEACgDADQgDAFgBAEQgCAGAAAFQAAAHACAFQABAEADAFQADADAEACQAEACAEAAQAIAAAFgEQAFgCAHgIIARARQgKANgHAEIgMAFQgGABgIABQgJAAgJgFg");
	this.shape_6.setTransform(120.2,16);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#002179").s().p("AgcAOIAAgbIA5AAIAAAbg");
	this.shape_7.setTransform(111.3,13.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#002179").s().p("AghA2IAAhoIAbAAIAAAHQAEgEAEgDQAGgCAHAAQAGAAAGACQAEABADADIgHAbIgHgEQgFgCgEAAQgFAAgDACQgDABgCACIgDAHIgBAKIAAA5g");
	this.shape_8.setTransform(104,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#002179").s().p("AgUA1QgHgDgFgEQgGgGgDgGQgDgIAAgIQAAgJADgHQADgFAGgFQAGgEAIgDQAHgBAJAAQAJAAAKADIAAgEQAAgHgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKAAQAKAAAIACQAIACAFAFQAGAFADAGQADAIAAAIIAABGIgcAAIAAgHQgDAEgGACQgHACgGABQgIAAgHgCgAgNAIQgEADAAAHQAAAFAEAEQAEAFAIgBQAGAAAFgCQAFgDACgFIAAgMQgDgDgEgBIgLgBQgIAAgEAEg");
	this.shape_9.setTransform(94.1,16);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#002179").s().p("AgHA2QgFgBgFgDQgIgDgHgIQgGgHgDgKQgEgKAAgMQAAgLAEgKQADgKAHgIQAGgHAJgEQAJgDAJAAQAJAAAJADQAIAFAGAHQAFAIADAKQADAKAAAKIAAAJIg+AAQABAFACAEIAEAGQAHAEAHABQAGAAAEgCQAFgCADgEIATARIgHAHIgJAFQgOAFgHAAIgLgBgAASgLQgBgIgDgFIgGgEQgDgCgFAAQgHAAgEAGQgEAFgCAIIAjAAIAAAAg");
	this.shape_10.setTransform(84.1,16);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002179").s().p("AgNBJIAAiDIAbgOIAACRg");
	this.shape_11.setTransform(76.5,13.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#002179").s().p("AgPAyQgJgDgGgIQgIgHgDgKQgEgKAAgMQAAgLAEgKQAEgKAGgIQAHgHAJgEQAKgDAKAAIAMABQAGABAFADIAJAHIAJAKIgSATQgGgIgFgDQgFgEgIAAQgEAAgEACQgEACgDADQgDAFgCAEQgBAGAAAFQAAAHABAFQACAEADAFQADADAEACQAEACAEAAQAIAAAFgEQAFgCAGgIIASARQgLANgGAEIgMAFQgGABgIABQgJAAgJgFg");
	this.shape_12.setTransform(69,16);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#002179").s().p("AgUA1QgHgDgFgEQgGgGgDgGQgDgIAAgIQAAgJADgHQADgFAGgFQAGgEAIgDQAHgBAJAAQAJAAAKADIAAgEQAAgHgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKAAQAKAAAIACQAIACAFAFQAGAFADAGQADAIAAAIIAABGIgcAAIAAgHQgDAEgGACQgHACgGABQgIAAgHgCgAgNAIQgEADAAAHQAAAFAEAEQAEAFAIgBQAGAAAFgCQAFgDACgFIAAgMQgDgDgEgBIgLgBQgIAAgEAEg");
	this.shape_13.setTransform(52.9,16);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#002179").s().p("AgHA2QgFgBgFgDQgIgDgHgIQgGgHgDgKQgEgKABgMQgBgLAEgKQADgKAHgIQAHgHAIgEQAIgDAKAAQAKAAAIADQAIAFAGAHQAFAIADAKQAEAKAAAKIgBAJIg9AAQAAAFABAEIAGAGQAFAEAIABQAFAAAFgCQAFgCADgEIATARIgHAHIgJAFQgOAFgHAAIgLgBgAATgLQgBgIgFgFIgFgEQgDgCgFAAQgGAAgFAGQgEAFgBAIIAjAAIAAAAg");
	this.shape_14.setTransform(37.1,16);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#002179").s().p("AAPBJIgSgwIgOAQIAAAgIgcAAIAAiDIAcgOIAABMIAbgjIAgAAIgbAgIAeBIg");
	this.shape_15.setTransform(27.8,13.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#002179").s().p("AgUA1QgHgDgFgEQgGgGgDgGQgDgIAAgIQAAgJADgHQADgFAGgFQAGgEAIgDQAHgBAJAAQAJAAAKADIAAgEQAAgHgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKAAQAKAAAIACQAIACAFAFQAGAFADAGQADAIAAAIIAABGIgcAAIAAgHQgDAEgGACQgHACgGABQgIAAgHgCgAgNAIQgEADAAAHQAAAFAEAEQAEAFAIgBQAGAAAFgCQAFgDACgFIAAgMQgDgDgEgBIgLgBQgIAAgEAEg");
	this.shape_16.setTransform(16.8,16);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#002179").s().p("AgNBGIAAhvIgoAAIAAgcIBrAAIAAAcIgoAAIAABvg");
	this.shape_17.setTransform(8,14.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt1, new cjs.Rectangle(0,0,192.3,28), null);


(lib.hotspot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hotspot, new cjs.Rectangle(0,0,300,250), null);


(lib.cursor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AAAj8IAAH5");
	this.shape.setTransform(0,25.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},5).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,2,52.6);


(lib.ball_violet = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AE22A4").s().p("AhiBjQgpgpgBg6QABg5ApgpQApgpA5gBQA6ABApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape.setTransform(14.1,14.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ball_violet, new cjs.Rectangle(0,0,28.1,28.1), null);


(lib.ball_teal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00C1B5").s().p("AhiBjQgpgpgBg6QABg5ApgpQApgpA5gBQA6ABApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape.setTransform(14.1,14.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ball_teal, new cjs.Rectangle(0,0,28.1,28.1), null);


(lib.ball_purple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6C28AA").s().p("AhiBjQgpgpgBg6QABg5ApgpQApgpA5gBQA6ABApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape.setTransform(14.1,14.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ball_purple, new cjs.Rectangle(0,0,28.1,28.1), null);


(lib.ball_magenta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E00090").s().p("AhiBjQgpgpgBg6QABg5ApgpQApgpA5gBQA6ABApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape.setTransform(14.1,14.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ball_magenta, new cjs.Rectangle(0,0,28.1,28.1), null);


(lib.ball_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1351D3").s().p("AhiBjQgpgpgBg6QABg5ApgpQApgpA5gBQA6ABApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape.setTransform(14.1,14.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ball_blue, new cjs.Rectangle(0,0,28.1,28.1), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#243374").s().p("AvabzMAcug1mIhAgiIC8h+IALDoIhLgoMgcuA1ng");
	this.shape.setTransform(98.7,181.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,197.4,362.3), null);


(lib.ARR = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAVIAjgVIgjgTIAAgSIA0AgIAAALIg0Agg");
	this.shape.setTransform(5.4,8.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ARR, new cjs.Rectangle(0,0,10.9,17.2), null);


(lib.qqq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_33 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(33).call(this.frame_33).wait(16));

	// Q
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA5CtQgaAKgfAAQgTABgSgEQgRgEgQgHQgPgHgNgKQgNgKgLgOQgLgNgIgQQgIgPgGgTQgIgYgDg3QAAgdALgzQAGgSAIgQQAIgQALgNQALgNANgKQANgKAPgHQAQgIARgDQASgEATAAQATAAASAEQASADAPAIQAQAHANAKQANAKALANQALANAIAQQAIAQAFASQAMAzAAAdQAAAXgEAVQgDAVgHATQgGASgKARQgKAPgMANIAcAqIg6AmgAgnh+QgRAIgKASQgLAQgFAWQgFAWAAAaQAAAaAFAWQAGAXALARQALASAQAJQASAKAVAAIAOgBIgZgmIA5gnIAZAlQAIgQAFgXQADgUAAgZQAAgagGgWQgEgWgLgQQgLgSgQgIQgSgKgWABQgWgBgRAKg");
	this.shape.setTransform(97.8,40.9);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(21).to({_off:false},0).wait(28));

	// Q
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA5CtQgaAKgfAAQgTABgRgEQgSgEgQgHQgPgHgNgKQgNgKgLgOQgLgNgIgQQgIgPgGgTQgHgYgEg3QAAgdALgzQAGgSAIgQQAIgQALgNQALgNANgKQANgKAPgHQAQgIASgDQARgEATAAQAUAAARAEQASADAQAIQAPAHANAKQANAKALANQALANAIAQQAIAQAFASQAMAzAAAdQAAAXgEAVQgDAVgHATQgHASgJARQgKAPgMANIAcAqIg7AmgAgnh+QgRAIgKASQgLAQgFAWQgFAWAAAaQAAAaAFAWQAGAXALARQAKASARAJQASAKAVAAIAOgBIgZgmIA5gnIAZAlQAIgQAEgXQAEgUAAgZQAAgagGgWQgEgWgLgQQgLgSgQgIQgSgKgWABQgWgBgRAKg");
	this.shape_1.setTransform(61.3,40.9);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(18).to({_off:false},0).wait(31));

	// Q
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA5CtQgaAKgfAAQgTABgRgEQgSgEgQgHQgPgHgNgKQgNgKgLgOQgLgNgIgQQgIgPgGgTQgHgYgEg3QAAgdALgzQAGgSAIgQQAIgQALgNQALgNANgKQANgKAPgHQAQgIASgDQARgEATAAQAUAAARAEQASADAQAIQAPAHANAKQANAKALANQALANAIAQQAIAQAFASQAMAzAAAdQAAAXgEAVQgDAVgHATQgHASgJARQgKAPgMANIAcAqIg7AmgAgnh+QgRAIgKASQgLAQgFAWQgFAWAAAaQAAAaAFAWQAGAXALARQAKASARAJQASAKAVAAIAOgBIgZgmIA5gnIAZAlQAIgQAEgXQAEgUAAgZQAAgagGgWQgEgWgLgQQgLgSgQgIQgSgKgWABQgWgBgRAKg");
	this.shape_2.setTransform(24.8,40.9);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(15).to({_off:false},0).wait(34));

	// cursor
	this.instance = new lib.cursor("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(6,41.4,1,1,0,0,0,0,25.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).wait(5).to({x:46,y:39.9,startPosition:2},0).wait(3).to({x:79.5,y:40.4},0).to({_off:true},3).wait(28));

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApSKcIAAy/IS6AAIAANLIlwF0g");
	mask.setTransform(61.6,66.8);

	// Layer 3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#18C1B5").s().p("AgOAPIAAgdIAdAAIAAAdg");
	this.shape_3.setTransform(-0.5,139.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#18C1B5").s().p("AiICIIAAkPIERAAIAAEPg");
	this.shape_4.setTransform(11.7,127.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#18C1B5").s().p("Aj1D0IAAnnIHrAAIAAHng");
	this.shape_5.setTransform(22.6,116.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#18C1B5").s().p("AlVFUIAAqnIKsAAIAAKng");
	this.shape_6.setTransform(32.3,107.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#18C1B5").s().p("AmpGnIAAtNINTAAIAANNg");
	this.shape_7.setTransform(40.6,98.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#18C1B5").s().p("AnwHtIAAvZIPhAAIAAPZg");
	this.shape_8.setTransform(47.7,91.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#18C1B5").s().p("AoqInIAAxNIRVAAIAARNg");
	this.shape_9.setTransform(53.6,86.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#18C1B5").s().p("ApYJUIAAynISxAAIAASng");
	this.shape_10.setTransform(58.1,81.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#18C1B5").s().p("Ap4J0IAAznITyAAIAATng");
	this.shape_11.setTransform(61.4,78.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#18C1B5").s().p("AqMKIIAA0PIUZAAIAAUPg");
	this.shape_12.setTransform(63.3,76.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#18C1B5").s().p("AqTKPIAA0dIUnAAIAAUdg");
	this.shape_13.setTransform(64,75.7);

	var maskedShapeInstanceList = [this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3}]}).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.main = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ball_blue
	this.instance = new lib.ball_blue();
	this.instance.parent = this;
	this.instance.setTransform(527.5,-226.4,29.998,29.998,0,0,0,14.2,14.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(116).to({_off:false},0).to({x:-375.2,y:448.4},22,cjs.Ease.get(-0.69)).wait(1));

	// ball_violet
	this.instance_1 = new lib.ball_violet();
	this.instance_1.parent = this;
	this.instance_1.setTransform(83,-54.3,0.23,0.23,0,0,0,14.6,14.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(65).to({_off:false},0).to({regX:14.3,regY:14.2,scaleX:0.44,scaleY:0.44,x:-39.4,y:52.3},33,cjs.Ease.get(1)).to({regY:14.1,scaleX:0.38,scaleY:0.38,x:-52.3,y:61.9},24,cjs.Ease.get(-0.3)).to({_off:true},9).wait(8));

	// ball_violet
	this.instance_2 = new lib.ball_violet();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-62.6,6.6,0.425,0.425,0,0,0,14.3,14.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(74).to({_off:false},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.43,scaleY:0.43,x:-67.3,y:10},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-71.8,y:13.2},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-76,y:16.4},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-80,y:19.4},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-83.9,y:22.2},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-87.5,y:24.9},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-91,y:27.4},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-94.2,y:29.8},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:-97.3,y:32.1},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-100.1,y:34.2},0).wait(1).to({x:-102.8,y:36.2},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-105.3,y:38},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-107.5,y:39.7},0).wait(1).to({x:-109.6,y:41.2},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-111.5,y:42.6},0).wait(1).to({x:-113.1,y:43.8},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-114.6,y:44.9},0).wait(1).to({x:-115.9,y:45.9},0).wait(1).to({x:-117,y:46.7},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-117.9,y:47.3},0).wait(1).to({x:-118.6,y:47.8},0).wait(1).to({x:-119.1,y:48.2},0).wait(1).to({x:-119.4,y:48.4},0).wait(1).to({regX:14.3,regY:14.2,y:48.6},0).to({regY:14.1,scaleX:0.38,scaleY:0.38,x:-116.2,y:54.4},24).to({_off:true},9).wait(8));

	// ball_violet
	this.instance_3 = new lib.ball_violet();
	this.instance_3.parent = this;
	this.instance_3.setTransform(40.8,-53.5,0.413,0.413,0,0,0,14.2,14.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(67).to({_off:false},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.41,scaleY:0.41,x:31.4,y:-50.2},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:24.5,y:-47.8},0).wait(1).to({regX:14.2,regY:14.2,scaleX:0.41,scaleY:0.41,x:20.2,y:-46.3},0).to({regX:14.3,scaleX:0.44,scaleY:0.44,x:-7.4,y:-20.8},14,cjs.Ease.get(1)).to({regY:14.1,scaleX:0.49,scaleY:0.49,x:-9.5,y:-21.8},38).to({_off:true},9).wait(8));

	// ball_violet
	this.instance_4 = new lib.ball_violet();
	this.instance_4.parent = this;
	this.instance_4.setTransform(25.7,-46.1,0.413,0.413,0,0,0,14.2,14.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(67).to({_off:false},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.41,scaleY:0.41,x:15.2,y:-42.5},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:7.6,y:-39.8},0).wait(1).to({regX:14.2,regY:14.2,scaleX:0.41,scaleY:0.41,x:2.9,y:-38.2},0).to({regX:14.3,scaleX:0.44,scaleY:0.44,x:-31.2,y:-11.9},14,cjs.Ease.get(1)).to({regY:14.1,scaleX:0.49,scaleY:0.49,x:-30.3,y:-12.9},38).to({_off:true},9).wait(8));

	// ball_violet
	this.instance_5 = new lib.ball_violet();
	this.instance_5.parent = this;
	this.instance_5.setTransform(31.1,-65.5,0.42,0.42,0,0,0,14.2,14.1);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(64).to({_off:false},0).to({scaleX:1.74,scaleY:1.74,x:-93.3,y:-55.4},6,cjs.Ease.get(0.72)).to({scaleX:1.9,scaleY:1.9,x:-114,y:-31.5},14,cjs.Ease.get(1)).to({scaleX:1.74,scaleY:1.74,x:-77.3,y:-41.4},38).to({_off:true},9).wait(8));

	// ball_violet
	this.instance_6 = new lib.ball_violet();
	this.instance_6.parent = this;
	this.instance_6.setTransform(80.4,-50.4,0.23,0.23,0,0,0,14.3,14.3);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(64).to({_off:false},0).to({scaleX:1.82,scaleY:1.82,x:-115.4,y:146.5},24,cjs.Ease.get(0.69)).to({_off:true},1).wait(50));

	// ball_violet
	this.instance_7 = new lib.ball_violet();
	this.instance_7.parent = this;
	this.instance_7.setTransform(89.7,-56.9,0.43,0.43,0,0,0,14.2,14.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(64).to({_off:false},0).to({scaleX:1.72,scaleY:1.72,x:126.4,y:16.4},11,cjs.Ease.get(1)).wait(1).to({regX:14.1,regY:14.1,x:127.1,y:16},0).wait(1).to({x:128.2,y:15.7},0).wait(1).to({x:129.3,y:15.3},0).wait(1).to({x:130.6,y:14.9},0).wait(1).to({x:132,y:14.5},0).wait(1).to({x:133.5,y:14},0).wait(1).to({x:135.2,y:13.4},0).wait(1).to({x:137,y:12.9},0).wait(1).to({x:138.9,y:12.3},0).wait(1).to({x:141,y:11.6},0).wait(1).to({x:143.2,y:10.9},0).wait(1).to({x:145.5,y:10.2},0).wait(1).to({x:147.9,y:9.4},0).wait(1).to({x:150.5,y:8.6},0).wait(1).to({x:153.1,y:7.7},0).wait(1).to({x:156,y:6.8},0).wait(1).to({x:158.9,y:5.9},0).wait(1).to({x:162,y:4.9},0).wait(1).to({x:165.2,y:3.9},0).wait(1).to({x:168.5,y:2.8},0).wait(1).to({x:172,y:1.7},0).wait(1).to({regX:14.2,regY:14.2,x:175.7,y:0.6},0).to({_off:true},1).wait(41));

	// ball_violet
	this.instance_8 = new lib.ball_violet();
	this.instance_8.parent = this;
	this.instance_8.setTransform(79.7,-61.8,0.43,0.43,0,0,0,14.2,14.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(64).to({_off:false},0).to({scaleX:3.78,scaleY:3.78,x:-105.1,y:46.8},9,cjs.Ease.get(-0.33)).to({x:-200.3,y:115.4},9,cjs.Ease.get(0.39)).to({_off:true},1).wait(56));

	// ball_purple
	this.instance_9 = new lib.ball_purple();
	this.instance_9.parent = this;
	this.instance_9.setTransform(80.3,-48.8,0.35,0.35,0,0,0,14.2,14);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(64).to({_off:false},0).to({regY:14.1,scaleX:1.59,scaleY:1.59,x:40.7,y:57.2},10,cjs.Ease.get(1)).to({scaleX:1.75,scaleY:1.75,x:37,y:78.3},18,cjs.Ease.get(1)).to({scaleX:1.85,scaleY:1.85,x:52.6,y:71.5},25).to({_off:true},14).wait(8));

	// ball_purple
	this.instance_10 = new lib.ball_purple();
	this.instance_10.parent = this;
	this.instance_10.setTransform(67.5,-82.3,0.35,0.35,0,0,0,14.2,14);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(64).to({_off:false},0).to({scaleX:1.48,scaleY:1.48,x:78,y:-78.5},10,cjs.Ease.get(1)).to({scaleX:2.21,scaleY:2.21,x:134.3,y:-139},43,cjs.Ease.get(-0.39)).to({_off:true},1).wait(21));

	// ball_magenta
	this.instance_11 = new lib.ball_magenta();
	this.instance_11.parent = this;
	this.instance_11.setTransform(25.7,-87,0.33,0.33,0,0,0,15,14.8);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(65).to({_off:false},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.38,scaleY:0.38,x:19.7,y:-86.4},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:14.3,y:-85.6},0).wait(1).to({scaleX:0.47,scaleY:0.47,x:9,y:-84.9},0).wait(1).to({scaleX:0.52,scaleY:0.52,x:4,y:-84.3},0).wait(1).to({scaleX:0.56,scaleY:0.56,x:-0.7,y:-83.6},0).wait(1).to({regX:14.9,regY:14.7,scaleX:0.6,scaleY:0.6,x:-4.7,y:-82.5},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.61,scaleY:0.61,x:-5.7,y:-82.8},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:-6.1},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:-6.5},0).wait(1).to({scaleX:0.65,scaleY:0.65,x:-6.9},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:-7.3},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:-7.7},0).wait(1).to({scaleX:0.67,scaleY:0.67,x:-8},0).wait(1).to({scaleX:0.68,scaleY:0.68,x:-8.3},0).wait(1).to({scaleX:0.69,scaleY:0.69,x:-8.5},0).wait(1).to({scaleX:0.69,scaleY:0.69,x:-8.8},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:-9},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:-9.2},0).wait(1).to({scaleX:0.71,scaleY:0.71,x:-9.4,y:-82.7},0).wait(1).to({scaleX:0.71,scaleY:0.71,x:-9.5},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:-9.6},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:-9.7,y:-82.8},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:-9.8,y:-82.7},0).wait(1).to({scaleX:0.72,scaleY:0.72},0).wait(1).to({regX:14.7,regY:14.7,x:-9.3,y:-82.3},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.72,scaleY:0.72,x:-9.1,y:-83.5},0).wait(1).to({regX:14.7,regY:14.6,x:-8.1,y:-83.9},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.72,scaleY:0.72,x:-7.9,y:-85},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:-7.3,y:-85.8},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:-6.7,y:-86.6},0).wait(1).to({x:-6.1,y:-87.4},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:-5.4,y:-88.2},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:-4.8,y:-89},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:-4.1,y:-89.8},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:-3.5,y:-90.7},0).wait(1).to({x:-2.8,y:-91.6},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:-2.1,y:-92.4},0).wait(1).to({regX:14.8,regY:14.7,scaleX:0.73,scaleY:0.73,x:-1.1,y:-92.9},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.73,scaleY:0.73,x:-1,y:-93.8},0).wait(1).to({scaleX:0.74,scaleY:0.74,x:-0.6,y:-94.4},0).wait(1).to({scaleX:0.74,scaleY:0.74,x:-0.1,y:-95},0).wait(1).to({scaleX:0.74,scaleY:0.74,x:0.5,y:-95.5},0).wait(1).to({scaleX:0.74,scaleY:0.74,x:1,y:-96.1},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:1.5,y:-96.6},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:2,y:-97.3},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:2.5,y:-97.8},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:3.1,y:-98.4},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:3.6,y:-99},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:4.2,y:-99.6},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:4.7,y:-100.2},0).wait(1).to({scaleX:0.77,scaleY:0.77,x:5.3,y:-100.9},0).wait(1).to({scaleX:0.77,scaleY:0.77,x:5.8,y:-101.5},0).wait(1).to({scaleX:0.77,scaleY:0.77,x:6.4,y:-102.1},0).wait(1).to({scaleX:0.78,scaleY:0.78,x:7,y:-102.7},0).wait(1).to({regX:14.8,regY:14.7,scaleX:0.78,scaleY:0.78,x:8.1,y:-103},0).to({_off:true},11).wait(8));

	// ball_magenta
	this.instance_12 = new lib.ball_magenta();
	this.instance_12.parent = this;
	this.instance_12.setTransform(44.1,-68.6,0.29,0.29,0,0,0,14.8,14.7);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(65).to({_off:false},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.33,scaleY:0.33,x:29.4,y:-65.8},0).wait(1).to({scaleX:0.37,scaleY:0.37,x:15.6,y:-63},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:2.3,y:-60.3},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:-10.4,y:-57.8},0).wait(1).to({scaleX:0.47,scaleY:0.47,x:-22.4,y:-55.3},0).wait(1).to({regX:14.8,regY:14.7,scaleX:0.51,scaleY:0.51,x:-33.6,y:-52.7},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.54,scaleY:0.54,x:-41,y:-48.4},0).wait(1).to({scaleX:0.56,scaleY:0.56,x:-47.7,y:-44},0).wait(1).to({scaleX:0.59,scaleY:0.59,x:-54,y:-39.9},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:-59.9,y:-36},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:-65.4,y:-32.5},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:-70.5,y:-29.1},0).wait(1).to({scaleX:0.68,scaleY:0.68,x:-75.3,y:-26},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:-79.7,y:-23.1},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:-83.7,y:-20.5},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:-87.3,y:-18.1},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:-90.5,y:-16},0).wait(1).to({scaleX:0.76,scaleY:0.76,x:-93.4,y:-14.1},0).wait(1).to({scaleX:0.77,scaleY:0.77,x:-95.9,y:-12.5},0).wait(1).to({scaleX:0.78,scaleY:0.78,x:-98,y:-11.1},0).wait(1).to({scaleX:0.79,scaleY:0.79,x:-99.7,y:-10},0).wait(1).to({scaleX:0.79,scaleY:0.79,x:-101,y:-9.1},0).wait(1).to({scaleX:0.8,scaleY:0.8,x:-102,y:-8.5},0).wait(1).to({scaleX:0.8,scaleY:0.8,x:-102.6,y:-8.2},0).wait(1).to({regX:14.7,regY:14.7,scaleX:0.8,scaleY:0.8,x:-102.2,y:-7.6},0).wait(1).to({regX:14.1,regY:14.1,x:-103.3,y:-7.3},0).wait(1).to({x:-103.9,y:-6.7},0).wait(1).to({x:-104.6,y:-6},0).wait(1).to({x:-105.3,y:-5.3},0).wait(1).to({x:-106,y:-4.6},0).wait(1).to({x:-106.7,y:-3.9},0).wait(1).to({x:-107.5,y:-3.2},0).wait(1).to({x:-108.2,y:-2.5},0).wait(1).to({x:-108.9,y:-1.7},0).wait(1).to({x:-109.7,y:-1},0).wait(1).to({x:-110.4,y:-0.2},0).wait(1).to({x:-111.2,y:0.5},0).wait(1).to({regX:14.8,regY:14.7,x:-111.5,y:1.7},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.8,scaleY:0.8,x:-112,y:1.4},0).wait(1).to({scaleX:0.79,scaleY:0.79,y:1.6},0).wait(1).to({scaleX:0.78,scaleY:0.78,y:1.8},0).wait(1).to({scaleX:0.78,scaleY:0.78,y:2},0).wait(1).to({scaleX:0.77,scaleY:0.77,y:2.2},0).wait(1).to({scaleX:0.77,scaleY:0.77,y:2.4},0).wait(1).to({scaleX:0.76,scaleY:0.76,y:2.7},0).wait(1).to({scaleX:0.76,scaleY:0.76,y:2.9},0).wait(1).to({scaleX:0.75,scaleY:0.75,y:3},0).wait(1).to({scaleX:0.74,scaleY:0.74,y:3.3},0).wait(1).to({scaleX:0.74,scaleY:0.74,y:3.5},0).wait(1).to({scaleX:0.73,scaleY:0.73,y:3.7},0).wait(1).to({scaleX:0.73,scaleY:0.73,y:3.9},0).wait(1).to({scaleX:0.72,scaleY:0.72,y:4.2},0).wait(1).to({scaleX:0.71,scaleY:0.71,y:4.4},0).wait(1).to({scaleX:0.71,scaleY:0.71,y:4.6},0).wait(1).to({regX:14.7,regY:14.7,scaleX:0.7,scaleY:0.7,x:-111.5,y:5.3},0).to({_off:true},11).wait(8));

	// ball_magenta
	this.instance_13 = new lib.ball_magenta();
	this.instance_13.parent = this;
	this.instance_13.setTransform(56.9,-73.1,0.15,0.15,0,0,0,14.7,14.7);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(65).to({_off:false},0).to({regX:14.8,regY:14.8,scaleX:0.44,scaleY:0.44,x:25.9,y:-35.1},25,cjs.Ease.get(1)).wait(1).to({regX:14.1,regY:14.1,scaleX:0.44,scaleY:0.44,x:25.8,y:-35.6},0).wait(1).to({x:26,y:-35.9},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:26.3,y:-36.1},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:26.6,y:-36.4},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:26.9,y:-36.7},0).wait(1).to({x:27.1,y:-37},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:27.4,y:-37.2},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:27.7,y:-37.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:28,y:-37.8},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:28.2,y:-38.1},0).wait(1).to({x:28.5,y:-38.4},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:28.8,y:-38.7},0).wait(1).to({regX:14.8,regY:14.8,scaleX:0.45,scaleY:0.45,x:29.4},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.45,scaleY:0.45,x:29.1,y:-39.2},0).wait(1).to({scaleX:0.45,scaleY:0.45,y:-39.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,y:-39.7},0).wait(1).to({scaleX:0.45,scaleY:0.45,y:-39.9},0).wait(1).to({scaleX:0.44,scaleY:0.44,y:-40.1},0).wait(1).to({scaleX:0.44,scaleY:0.44,y:-40.4},0).wait(1).to({scaleX:0.44,scaleY:0.44,y:-40.6},0).wait(1).to({scaleX:0.44,scaleY:0.44,y:-40.8},0).wait(1).to({scaleX:0.44,scaleY:0.44,y:-41.1},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:29.2,y:-41.3},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:29.1,y:-41.6},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:29.2,y:-41.8},0).wait(1).to({scaleX:0.44,scaleY:0.44,y:-42},0).wait(1).to({scaleX:0.43,scaleY:0.43,y:-42.3},0).wait(1).to({scaleX:0.43,scaleY:0.43,y:-42.5},0).wait(1).to({scaleX:0.43,scaleY:0.43,y:-42.8},0).wait(1).to({regX:14.8,regY:14.7,scaleX:0.43,scaleY:0.43,x:29.5},0).to({_off:true},11).wait(8));

	// ball_magenta
	this.instance_14 = new lib.ball_magenta();
	this.instance_14.parent = this;
	this.instance_14.setTransform(89.1,-69.4,0.15,0.15,0,0,0,14.7,14.7);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(64).to({_off:false},0).to({regX:14.8,scaleX:0.28,scaleY:0.28,x:90.9,y:-62.3},1).to({regX:14.7,scaleX:0.8,scaleY:0.8,x:-0.8,y:36.6},25,cjs.Ease.get(1)).to({x:-29.2,y:54.8},30,cjs.Ease.get(-0.16)).to({_off:true},11).wait(8));

	// ball_magenta
	this.instance_15 = new lib.ball_magenta();
	this.instance_15.parent = this;
	this.instance_15.setTransform(70.3,-80.2,0.37,0.37,0,0,0,14.6,14.3);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(64).to({_off:false},0).to({x:82.4},3).to({x:77.4,y:-71.1},4).to({scaleX:0.47,scaleY:0.47,x:66.7,y:-58.5},14,cjs.Ease.get(0.85)).to({regX:14.7,regY:14.5,scaleX:0.62,scaleY:0.62,x:72.9,y:-75},27,cjs.Ease.get(0.12)).to({_off:true},19).wait(8));

	// ball_magenta
	this.instance_16 = new lib.ball_magenta();
	this.instance_16.parent = this;
	this.instance_16.setTransform(108.6,-62.6,0.37,0.37,0,0,0,14.2,14.2);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(64).to({_off:false},0).wait(1).to({regX:14.1,regY:14.1,scaleX:0.79,scaleY:0.79,x:134.2,y:-39.4},0).wait(1).to({regX:14.2,regY:14.2,scaleX:1.1,scaleY:1.1,x:153.6,y:-21.9},0).wait(1).to({regX:14.1,regY:14.1,scaleX:1.03,scaleY:1.03,x:165.1,y:1.2},0).wait(1).to({regX:14.2,regY:14.2,scaleX:1,scaleY:1,x:171.2,y:13.2},0).to({scaleX:2.67,scaleY:2.67,x:110.9,y:156.9},23,cjs.Ease.get(0.44)).to({_off:true},1).wait(47));

	// ball_blue
	this.instance_17 = new lib.ball_blue();
	this.instance_17.parent = this;
	this.instance_17.setTransform(44.8,-43.5,0.14,0.14,0,0,0,14.3,14.3);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(65).to({_off:false},0).to({regX:14.5,regY:14.2,scaleX:0.29,scaleY:0.29,x:22.6,y:-33.7},1).to({regX:14.2,regY:14.3,scaleX:0.39,scaleY:0.39,x:-84.3,y:36.9},9).to({regY:14.5,scaleX:0.45,scaleY:0.45,x:-129.1,y:76.5},20,cjs.Ease.get(1)).to({regY:14.4,scaleX:0.4,scaleY:0.4,x:-119.7,y:78.2},29).to({_off:true},1).wait(14));

	// ball_blue
	this.instance_18 = new lib.ball_blue();
	this.instance_18.parent = this;
	this.instance_18.setTransform(66,-41.3,0.14,0.14,0,0,0,14.3,14.3);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(64).to({_off:false},0).to({regY:14.2,scaleX:0.37,scaleY:0.37,x:22.6,y:20.8},3).to({regX:14.2,scaleX:0.52,scaleY:0.52,x:-6.6,y:62.1},12).to({x:28.4,y:48.4},40).to({_off:true},1).wait(19));

	// ball_blue
	this.instance_19 = new lib.ball_blue();
	this.instance_19.parent = this;
	this.instance_19.setTransform(93.1,-72.3,0.75,0.75,0,0,0,14.2,14.2);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(64).to({_off:false},0).to({scaleX:1.97,scaleY:1.97,x:154.7,y:-62.3},12,cjs.Ease.get(1)).to({x:174,y:-72},7).to({_off:true},1).wait(55));

	// ball_blue
	this.instance_20 = new lib.ball_blue();
	this.instance_20.parent = this;
	this.instance_20.setTransform(71.8,-90.2,0.37,0.37,0,0,0,14.2,14.2);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(64).to({_off:false},0).to({scaleX:1.08,scaleY:1.08,y:-129.6},2).to({_off:true},1).wait(4).to({_off:false,x:35.1,y:-134.9},0).to({scaleX:2.79,scaleY:2.79,x:-117.4,y:-92.4},28,cjs.Ease.get(0.6)).to({scaleX:2.54,scaleY:2.54,x:-166.9,y:-50.9},24,cjs.Ease.get(0.22)).to({_off:true},8).wait(8));

	// Layer 23
	this.instance_21 = new lib.ball_teal();
	this.instance_21.parent = this;
	this.instance_21.setTransform(-64.3,-125.2,0.69,0.69,0,0,0,14.1,14.1);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(41).to({_off:false},0).to({x:-154.2,y:-49.7},7).to({_off:true},1).wait(90));

	// Layer 24
	this.instance_22 = new lib.ball_purple();
	this.instance_22.parent = this;
	this.instance_22.setTransform(37.4,-124.1,1,1,0,0,0,14.1,14.1);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(16).to({_off:false},0).to({scaleX:1.24,scaleY:1.24,x:-144.2,y:39.2},8).to({_off:true},1).wait(6).to({_off:false,scaleX:1,scaleY:1,x:43.2,y:-118.5},0).to({regX:14,scaleX:1.36,scaleY:1.36,x:-139.7,y:48.4},8).to({_off:true},1).wait(99));

	// Layer 25
	this.instance_23 = new lib.ball_teal();
	this.instance_23.parent = this;
	this.instance_23.setTransform(155.2,-28.4,1,1,0,0,0,14.1,14.1);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(7).to({_off:false},0).to({x:7.3,y:119.4},11).to({_off:true},1).wait(5).to({_off:false,x:155.2,y:-28.4},0).to({x:9.6,y:125.4},9).to({_off:true},1).wait(11).to({_off:false,regX:14.2,scaleX:0.86,scaleY:0.86,x:151.4,y:-11.2},0).to({regX:14.1,scaleX:1,scaleY:1,x:28.3,y:122.4},9).to({_off:true},1).wait(3).to({_off:false,regX:14.2,scaleX:0.86,scaleY:0.86,x:134.6,y:-128.5},0).to({regX:14.1,scaleX:1,scaleY:1,x:78.6,y:-75.7},5).to({x:-3.4,y:5.3},35,cjs.Ease.get(1)).to({_off:true},33).wait(8));

	// Layer 26
	this.instance_24 = new lib.arrow();
	this.instance_24.parent = this;
	this.instance_24.setTransform(-250.4,249.1,1,1,17.2,0,0,98.6,181.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).to({regX:98.7,x:-58.8,y:59.8},63).to({x:-140.8,y:140.8},35,cjs.Ease.get(1)).to({_off:true},33).wait(8));

	// ball_violet
	this.instance_25 = new lib.ball_violet();
	this.instance_25.parent = this;
	this.instance_25.setTransform(50.3,-40.2,0.42,0.42,0,0,0,14.2,14.1);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(64).to({_off:false},0).to({scaleX:1.74,scaleY:1.74,x:-38.4,y:16.3},6,cjs.Ease.get(0.72)).to({regY:14.2,scaleX:1.64,scaleY:1.64,x:-51.4,y:25.2},14,cjs.Ease.get(1)).to({regY:14.1,x:-10.8,y:7.4},38).to({_off:true},9).wait(8));

	// ball_purple
	this.instance_26 = new lib.ball_purple();
	this.instance_26.parent = this;
	this.instance_26.setTransform(70.4,-80,0.35,0.35,0,0,0,14.2,14);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(64).to({_off:false},0).to({regX:14.3,regY:14.1,scaleX:0.66,scaleY:0.66,x:40.7,y:-35},10,cjs.Ease.get(0.22)).to({scaleX:0.83,scaleY:0.83,x:31.9,y:-21.3},18,cjs.Ease.get(1)).to({regY:14.2,scaleX:0.86,scaleY:0.86,x:29.8,y:-22.4},25).to({_off:true},14).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-398.2,46.9,295.7,404.5);


(lib.CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{over:6});

	// timeline functions:
	this.frame_35 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(35).call(this.frame_35).wait(1));

	// START WITH INVESCO QQQ
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AALAjQgFACgGAAIgHgBIgGgCIgFgEIgGgEIgDgGIgDgHQgCgFgBgKQAAgGADgKIADgHIADgGIAGgEIAFgEIAGgCIAHgBIAIABIAHACIAFAEIAFAEIADAGIAEAHIACAQIgBAIIgCAIIgEAHIgEAGIAGAIIgMAIgAgHgZIgFAGIgEAHIgBAKIABAJQABAEADAEQACADADACQAEACADAAIADAAIgEgIIAKgHIAGAHIACgHIAAgJIAAgKIgDgHQgDgEgDgCQgEgBgEAAQgEAAgDABg");
	this.shape.setTransform(156.7,13.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AALAjQgEACgHAAIgHgBIgGgCIgFgEIgGgEIgDgGIgDgHQgCgFgBgKQABgGACgKIADgHIADgGIAGgEIAFgEIAGgCIAHgBIAIABIAHACIAFAEIAFAEIADAGIADAHQADAKAAAGIgBAIIgCAIIgEAHIgEAGIAGAIIgMAIgAgHgZIgGAGIgDAHIgBAKIABAJQACAEACAEQACADADACQAEACADAAIADAAIgEgIIAKgHIAGAHIACgHIABgJIgBgKIgEgHQgBgEgEgCQgDgBgFAAQgDAAgEABg");
	this.shape_1.setTransform(148.9,13.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AALAjQgEACgHAAIgHgBIgGgCIgFgEIgGgEIgDgGIgDgHQgBgFgCgKQABgGACgKIADgHIADgGIAGgEIAFgEIAGgCIAHgBIAIABIAGACIAGAEIAFAEIADAGIADAHIADAQIgBAIIgCAIIgDAHIgFAGIAGAIIgMAIgAgHgZIgGAGIgDAHIAAAKIAAAJQACAEACAEQACADADACQAEACAEAAIACAAIgEgIIALgHIAEAHIADgHIABgJIgBgKIgEgHQgCgEgDgCQgDgBgFAAQgDAAgEABg");
	this.shape_2.setTransform(141.2,13.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHAnIgGgCIgFgDIgGgEIgDgHIgDgGIgDgIIAAgJIAAgIIADgHIADgHIADgGIAGgEIAFgEIAHgCIAGgBIAHABIAHACIAFAEIAGAEIADAGIAEAGIABAIIABAIIgBAIIgBAIIgEAHIgDAGIgGAEIgFAEIgHACIgHABIgHgBgAgHgWIgFAFIgEAHIgBAKIABAKQACAFACADQACADADACQAEACADgBQAEABAEgCIAFgFQACgDACgEQABgFAAgGQAAgEgBgGQgCgEgCgDIgGgFQgDgCgEABQgEgBgDACg");
	this.shape_3.setTransform(130.1,13.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAnIgGgCIgGgEIgFgEIgEgGIgCgGIgCgHIgBgKIABgHIABgIIADgHIAFgGIAEgEIAGgEIAHgCIAGgBIAJABIAIAEQAEABACAEQADADACAEIgOAHQgCgEgDgCQgEgDgFABQgDAAgEABQgDACgDAEIgDAHIgBAJIABAKIAEAHQACAEADACQAEABADAAQAFAAADgBQAEgDADgGIANAJIgFAHQgCADgEACQgDADgFABIgJABIgHgBg");
	this.shape_4.setTransform(122.6,13.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgIAnIgIgDIgIgFQgDgCgCgEIALgJIAEAEIAFADQAFABAFAAQAIAAACgBQADgCAAgFIgBgDIgCgCQgHgEgGgBIgKgDQgEgCgEgBIgEgGQgCgEAAgGQAAgFACgEQACgFAEgCQADgDAGgCIAKgCIAIABIAIACQAEADAIAGIgLALQgFgEgDgCQgFgCgFAAQgFAAgCACQgDADAAACQAAAEADABIALAFIALADIAIAEQADACACADQACAFAAAFQAAAGgBAEQgCAEgEAEQgEADgGACQgFABgIABIgIgBg");
	this.shape_5.setTransform(115.4,13.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIA0AAIAAAQIgmAAIAAANIAfAAIAAAOIgfAAIAAASIAoAAIAAAQg");
	this.shape_6.setTransform(108.7,13.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgHAnIgbhNIARAAIARA3IASg3IARAAIgcBNg");
	this.shape_7.setTransform(101.1,13.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARAnIgggxIAAAxIgPAAIAAhNIAPAAIAfAwIAAgwIAPAAIAABNg");
	this.shape_8.setTransform(93.2,13.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgHAnIAAhNIAPAAIAABNg");
	this.shape_9.setTransform(87.3,13.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQAnIAAghIgfAAIAAAhIgPAAIAAhNIAPAAIAAAeIAfAAIAAgeIAPAAIAABNg");
	this.shape_10.setTransform(78.1,13.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgHAnIAAg9IgWAAIAAgQIA7AAIAAAQIgWAAIAAA9g");
	this.shape_11.setTransform(70.6,13.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHAnIAAhNIAPAAIAABNg");
	this.shape_12.setTransform(65.4,13.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAMAnIgMgyIgLAyIgPAAIgQhNIAQAAIAIAwIAMgwIAMAAIAMAwIAJgwIAQAAIgRBNg");
	this.shape_13.setTransform(58.8,13.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgHAnIAAg9IgWAAIAAgQIA7AAIAAAQIgWAAIAAA9g");
	this.shape_14.setTransform(47.2,13.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AANAnIgNgcIgPAAIAAAcIgPAAIAAhNIAiAAQAGABAFABQAEACAEADQAEADACAEQACAFAAAGIgBAIQAAAEgCACIgGAEIgFADIAOAfgAgPgDIATAAIAFAAIADgCQADgDABgFIgCgFIgCgDQgDgBgFAAIgTAAg");
	this.shape_15.setTransform(40.4,13.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAUAnIgGgRIgbAAIgHARIgQAAIAdhNIAOAAIAeBNgAAIAGIgIgYIgIAYIAQAAg");
	this.shape_16.setTransform(32.2,13.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgHAnIAAg9IgWAAIAAgQIA7AAIAAAQIgWAAIAAA9g");
	this.shape_17.setTransform(25.8,13.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgIAnIgIgDIgHgFQgEgCgCgEIALgJIAEAEIAFADQAFABAFAAQAIAAACgBQADgCAAgFIgBgDIgCgCQgHgEgGgBIgKgDQgEgCgEgBIgEgGQgCgEAAgGQAAgFACgEQACgFAEgCQADgDAFgCIALgCIAIABIAHACQAGADAHAGIgLALQgFgEgDgCQgFgCgFAAQgFAAgCACQgDADAAACQAAAEADABIALAFIALADIAIAEQADACACADQACAFAAAFQAAAGgBAEQgCAEgEAEQgEADgGACQgFABgIABIgIgBg");
	this.shape_18.setTransform(19,13.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(36));

	// Layer 3
	this.instance = new lib.ARR();
	this.instance.parent = this;
	this.instance.setTransform(168.3,13.4,1,1,0,0,0,5.5,8.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36));

	// Layer 6
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],-164,0,-101.9,0).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_19.setTransform(92,12.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],-110.3,0.2,-48.2,0.2).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_20.setTransform(92,12.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],-62.9,0.4,-0.8,0.4).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_21.setTransform(92,12.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],-21.8,0.6,40.3,0.6).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_22.setTransform(92,12.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],13,0.7,75.1,0.7).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_23.setTransform(92,12.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],41.4,0.8,103.5,0.8).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_24.setTransform(92,12.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],63.5,0.9,125.6,0.9).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_25.setTransform(92,12.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],79.3,1,141.4,1).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_26.setTransform(92,12.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],88.8,1,150.9,1).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_27.setTransform(92,12.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.569)","rgba(255,255,255,0)"],[0,0.471,1],92,1,154.1,1).s().p("AuXCgIAAk/IcvAAIAAE/g");
	this.shape_28.setTransform(92,12.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_19}]},8).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).wait(19));

	// Layer 1
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E00090").s().p("AuSCPIAAkdIclAAIAAEdg");
	this.shape_29.setTransform(91.5,14.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(36));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,183,28.5);


// stage content:
(lib.invesco_QQQ_300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_295 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(295).call(this.frame_295).wait(1));

	// hotspot
	this.hotspot = new lib.hotspot();
	this.hotspot.parent = this;
	this.hotspot.setTransform(150.6,124.6,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.hotspot).wait(296));

	// Layer 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("A3WzcMAutAAAMAAAAm5MgutAAAg");
	this.shape.setTransform(150.5,124.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(296));

	// logo
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#001C86").s().p("AgsAtQgTgSAAgbQAAgZATgTQATgTAZAAQAaAAAUASQASAUAAAZQAAAbgSASQgUATgaAAQgaAAgSgTgAgVgWQgJAKAAAMQAAANAJAKQAIAKANAAQANAAAJgKQAKgJgBgOQABgMgKgKQgJgKgNAAQgNAAgIAKg");
	this.shape_1.setTransform(50,38.1,0.52,0.52);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#001C86").s().p("AgmAtQgTgSAAgbQAAgZATgTQATgTAZAAQAhAAATAbIgaATQgJgPgRAAQgNAAgIAKQgJAKAAAMQAAANAJAKQAIAKANAAQARAAAJgPIAaATQgTAbghAAQgaAAgSgTg");
	this.shape_2.setTransform(43.2,38.1,0.52,0.52);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#001C86").s().p("AgzAvIAPgWQAXAMAOgBQAJAAAFgDQAFgDAAgFQAAgHgTgEQgZgFgJgFQgRgIAAgVQAAgRAPgLQAPgKAUAAQAYAAAVAPIgQAVQgSgIgLgBQgTABAAAIQAAAGAKADIAQAEQAWAFAJAGQAOAIAAATQAAASgQALQgQALgUAAQgZAAgagRg");
	this.shape_3.setTransform(36.8,38.1,0.52,0.52);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#001C86").s().p("AgnAvQgRgSAAgdQAAgbARgSQARgSAXAAQAZAAAQATQAPASAAAaIAAALIhQAAQACALAIAGQAIAFAJAAQAPABAIgLIAZASQgRAXgfAAQgaAAgRgRgAgPgdQgGAHgCAJIAwAAQgDgWgWAAQgIAAgHAGg");
	this.shape_4.setTransform(30.2,38.1,0.52,0.52);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#001C86").s().p("AgPA9Igth5IAkAAIAZBTIAZhTIAjAAIgsB5g");
	this.shape_5.setTransform(23.8,38.1,0.52,0.52);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#001C86").s().p("AAVA/IAAhCQAAgQgFgGQgFgGgLAAQgKAAgEAGQgGAGAAAPIAABDIggAAIAAh6IAgAAIAAAIQAKgLASAAQAtAAAAA4IAABFg");
	this.shape_6.setTransform(17.4,38.1,0.52,0.52);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#001C86").s().p("AgPBVIAAiZIAfgQIAACpg");
	this.shape_7.setTransform(12.3,36.9,0.52,0.52);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#001C86").s().p("AhmDeIAOgeIAAgdIgsAAIg7A7IgsgPIAAg7IhKgMIg4AcIgggQIAAg7ICThKIAPAOIAsgrIAAgdIA7g7IAeg8IAshKIBJgOIAdAAIAAAdIA7A7IAAA7IBZBZIBYA6IAsAPIAPAsIA7AeIgdAeIgeAAIAAgeIgsgPIhKhKIg7gdIg7hYIgdgeIAOgsIgsgsIgdAdIAAA8IgdAdIA6A7IgdAdIA7A7IAAAdIAdA8IAeAAIAdgeIgPgPIgOgsIAdAAIAeA7IAdAdIhYAeIgeAeIgdgeIgPgsIgsgPIAAgeIgdAAIgPBKIAPAtIhEAdg");
	this.shape_8.setTransform(32.2,19.4,0.52,0.52);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(296));

	// cta
	this.cta = new lib.CTA();
	this.cta.parent = this;
	this.cta.setTransform(146.2,168,1,1,0,0,0,91.5,14.2);
	this.cta.alpha = 0;
	this.cta._off = true;

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(194).to({_off:false},0).to({y:153,alpha:1},8).wait(94));

	// ball animation
	this.instance = new lib.main("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(143.6,136.6,1,1,44.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(52).to({_off:false},0).to({_off:true},142).wait(102));

	// Layer 11
	this.instance_1 = new lib.InvescoDistributorsInc();
	this.instance_1.parent = this;
	this.instance_1.setTransform(114,235,0.495,0.495);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(182).to({_off:false},0).wait(114));

	// Layer 10
	this.cta_1 = new lib.CTA();
	this.cta_1.parent = this;
	this.cta_1.setTransform(149.1,152.8,1,1,0,0,0,91.5,14.2);
	this.cta_1.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.cta_1).wait(182).to({_off:true},1).wait(113));

	// qqq
	this.instance_2 = new lib.qqq("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(148.7,124.6,1,1,0,0,0,61.6,66.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(26).to({startPosition:26},0).to({scaleX:0.97,scaleY:0.97,y:124.7,startPosition:28},2).to({scaleX:1.09,scaleY:1.09,startPosition:30},2).to({scaleX:1,scaleY:1,y:124.6,startPosition:32},2).wait(3).to({startPosition:31},0).to({x:-87.9},8,cjs.Ease.get(1)).wait(138).to({x:367.6,startPosition:43},0).to({_off:true},1).wait(113));

	// txt1
	this.instance_3 = new lib.txt1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(147.1,88,1,1,0,0,0,95.2,14);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#002179").s().p("AgMAOQgGgGAAgIQAAgHAGgGQAEgFAIAAQAIAAAFAFQAGAGAAAHQAAAEgCAEIgEAGQgFAFgIAAQgIAAgEgFg");
	this.shape_9.setTransform(281.7,120.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#002179").s().p("AgMAzIAOgDQAGgBADgCQADgCACgFQACgEAAgGIAAAAQgFAEgEACQgHACgFAAQgJAAgHgDQgIgEgFgGQgGgHgDgKQgCgGgBgTQAAgMACgKQADgJAFgIQAGgGAHgEQAIgEAKAAQAFAAAGACQAGACAEAEIAAgGIAbAAIAABYQgBASgCAHQgDAKgHAGQgGAGgJAEQgJADgMABgAgHgsIgFAEIgDAJIgBAMQAAAHABAGQABAGADADQACAEADACQAEABADAAQAFAAAEgCQAFgCADgFIAAgmQgDgEgEgDQgFgCgGAAQgEAAgDACg");
	this.shape_10.setTransform(273.3,118.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#002179").s().p("AASA1IAAg3IgBgLQgBgFgCgCQgDgDgDgCQgDgBgFgBIgHABQgDACgCADQgDACgBAFIgBALIAAA4IgcAAIAAhnIAcAAIAAAGQAEgEAGgCQAHgDAHAAQAKAAAHAEQAHADAFAHQAEAGADAIQADAJgBAMIAAA5g");
	this.shape_11.setTransform(262.9,116.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#002179").s().p("AgNBIIAAhnIAbAAIAABngAgKgtQgFgFAAgGQAAgHAFgEQAFgEAFgBQAGABAFAEQAFAEAAAHQAAAGgFAFQgFAFgGAAQgFAAgFgFg");
	this.shape_12.setTransform(254.8,114.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#002179").s().p("AAABIQgGgDgDgDQgEgFgCgFQgCgHAAgHIAAgwIgRAAIAAgaIARAAIAAgbIAbgOIAAApIAZAAIAAAaIgZAAIAAApQAAAIACACQACADAGAAQAEAAADgCIAJgGIgFAcIgJAFQgFABgHAAQgGAAgEgCg");
	this.shape_13.setTransform(247.8,115);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#002179").s().p("AgWAzQgLgCgJgHIAJgUQAIAEAJADQAJACAJAAQAIAAADgCQADgBAAgFQAAgEgDgCIgMgEIgQgGQgIgEgGgDQgFgDgCgGQgEgGAAgHQAAgIAEgHQADgGAFgEQAFgDAIgCQAIgCAJAAQAJAAAKADQALACAIAFIgJAXQgHgFgJgCQgHgCgHAAQgHAAgDABQgDABgBAFQAAADAFACIARAHIANAFIALAGQAFAEACAEQADAHABAHQAAAIgEAIQgDAFgGAFQgGADgIACQgHABgJAAQgLAAgMgDg");
	this.shape_14.setTransform(239.2,116.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#002179").s().p("AgHA1QgFAAgFgDQgIgDgHgIQgGgHgDgJQgEgLABgMQgBgLAEgKQADgKAHgIQAHgHAIgDQAIgFAKAAQAKAAAIAFQAIAEAGAHQAFAIADAKQAEAKAAAKIgBAJIg9AAQAAAFABAEIAGAGQAFAFAIAAQAFgBAFgCQAFgCADgCIATAQIgHAHIgJAFQgOAEgHAAIgLgBgAATgLQgBgIgFgFIgFgEQgDgBgFgBQgGABgFAFQgEAFgBAIIAjAAIAAAAg");
	this.shape_15.setTransform(229.3,116.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#002179").s().p("AgNA0IgmhnIAeAAIAWBDIAVhDIAeAAIgmBng");
	this.shape_16.setTransform(219.2,116.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#002179").s().p("AASA1IAAg3IgBgLQgBgFgDgCQgBgDgEgCQgDgBgFgBIgGABQgEACgDADQgCACgBAFIgBALIAAA4IgcAAIAAhnIAcAAIAAAGQAEgEAGgCQAHgDAGAAQAKAAAIAEQAHADAFAHQAEAGADAIQADAJAAAMIAAA5g");
	this.shape_17.setTransform(208.8,116.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#002179").s().p("AgNBIIAAhnIAbAAIAABngAgKgtQgFgFAAgGQAAgHAFgEQAFgEAFgBQAGABAFAEQAFAEAAAHQAAAGgFAFQgFAFgGAAQgFAAgFgFg");
	this.shape_18.setTransform(200.7,114.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#002179").s().p("AASBJIAAg5IgBgLQgBgEgDgDQgCgDgCgBIgJgBIgHABQgDABgDADQgBACgCAEIgBALIAAA6IgbAAIAAiDIAbgOIAAAwQAEgEAGgDQAHgCAHAAQAJAAAIADQAHADAFAHQAFAGACAJQACAIAAALIAAA7g");
	this.shape_19.setTransform(187.2,114.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#002179").s().p("AgBBIQgFgDgEgDQgDgFgCgFQgCgHAAgHIAAgwIgSAAIAAgaIASAAIAAgbIAagOIAAApIAaAAIAAAaIgaAAIAAApQAAAIAEACQACADAFAAQAEAAADgCIAIgGIgDAcIgJAFQgHABgGAAQgGAAgFgCg");
	this.shape_20.setTransform(177.1,115);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#002179").s().p("AAQA0IgQg+IgPA+IgXAAIgehnIAcAAIAOA6IAQg6IAWAAIAQA6IAOg6IAbAAIgeBng");
	this.shape_21.setTransform(166.3,116.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#002179").s().p("AgSAyQgIgEgHgGQgHgIgDgKQgEgKABgMQgBgLAEgKQADgKAHgIQAHgHAIgDQAJgFAJAAQAKAAAJAFQAIADAHAHQAHAIADAKQAEAKgBALQABAMgEAKQgDAKgHAIQgHAGgIAEQgJAEgKAAQgJAAgJgEgAgIgZQgEACgCAEIgDAJIgBAKIABAMQABAFACADQACAEAEACQAEACAEAAQAFAAAEgDQADgCADgDQACgEABgFIABgLIgBgKIgDgJQgDgEgDgCQgEgCgFAAQgEAAgEACg");
	this.shape_22.setTransform(154.3,116.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#002179").s().p("AghA1IAAhnIAbAAIAAAGQAEgEAEgCQAGgDAHAAQAGAAAGADQAEACADACIgHAbIgHgEQgFgCgEAAQgFAAgDACQgDABgCACIgDAIIgBAKIAAA3g");
	this.shape_23.setTransform(145.9,116.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#002179").s().p("AgMAzIAOgDQAGgBADgCQADgCACgFQACgEAAgGIAAAAQgFAEgEACQgHACgFAAQgJAAgHgDQgIgEgFgGQgGgHgDgKQgCgGgBgTQAAgMACgKQADgJAFgIQAGgGAHgEQAIgEAKAAQAFAAAGACQAGACAEAEIAAgGIAbAAIAABYQgBASgCAHQgDAKgHAGQgGAGgJAEQgJADgMABgAgHgsIgFAEIgDAJIgBAMQAAAHABAGQABAGADADQACAEADACQAEABADAAQAFAAAEgCQAFgCADgFIAAgmQgDgEgEgDQgFgCgGAAQgEAAgDACg");
	this.shape_24.setTransform(135.8,118.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#002179").s().p("AAvA1IAAg3IgBgMIgDgHIgFgFIgHgBIgIABQgDACgCADQgCACgBAFIgBALIAAA4IgbAAIAAg3IgBgMIgDgHIgFgFIgIgBIgHABQgEACgCADQgCACgBAFIgBALIAAA4IgbAAIAAhnIAbAAIAAAGQAEgEAFgCQAHgDAHAAQAKAAAHAEQAGADAFAHQAHgGAGgDIAJgEIAMgBQAJAAAIAEQAHADAEAHQAFAGACAIQACAJAAAMIAAA5g");
	this.shape_25.setTransform(116.8,116.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#002179").s().p("AghA1IAAhnIAbAAIAAAGQAEgEAEgCQAGgDAHAAQAGAAAGADQAEACADACIgHAbIgHgEQgFgCgEAAQgFAAgDACQgDABgCACIgDAIIgBAKIAAA3g");
	this.shape_26.setTransform(104.7,116.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#002179").s().p("AgHA1QgFAAgFgDQgIgDgHgIQgGgHgDgJQgEgLABgMQgBgLAEgKQADgKAHgIQAHgHAIgDQAIgFAKAAQAKAAAIAFQAIAEAGAHQAFAIADAKQAEAKAAAKIgBAJIg9AAQAAAFABAEIAGAGQAFAFAIAAQAFgBAFgCQAFgCADgCIATAQIgHAHIgJAFQgOAEgHAAIgLgBgAATgLQgBgIgFgFIgFgEQgDgBgFgBQgGABgFAFQgEAFgBAIIAjAAIAAAAg");
	this.shape_27.setTransform(95.2,116.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#002179").s().p("AgBBIQgEgDgFgDQgDgFgCgFQgCgHAAgHIAAgwIgRAAIAAgaIARAAIAAgbIAbgOIAAApIAZAAIAAAaIgZAAIAAApQAAAIACACQADADAFAAQAEAAADgCIAJgGIgFAcIgJAFQgFABgHAAQgGAAgFgCg");
	this.shape_28.setTransform(86.1,115);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#002179").s().p("AgcAOIAAgbIA5AAIAAAbg");
	this.shape_29.setTransform(78.6,114.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#002179").s().p("AgMAzIAOgDQAGgBADgCQADgCACgFQACgEAAgGIAAAAQgFAEgEACQgHACgFAAQgJAAgHgDQgIgEgFgGQgGgHgDgKQgCgGgBgTQAAgMACgKQADgJAFgIQAGgGAHgEQAIgEAKAAQAFAAAGACQAGACAEAEIAAgGIAbAAIAABYQgBASgCAHQgDAKgHAGQgGAGgJAEQgJADgMABgAgHgsIgFAEIgDAJIgBAMQAAAHABAGQABAGADADQACAEADACQAEABADAAQAFAAAEgCQAFgCADgFIAAgmQgDgEgEgDQgFgCgGAAQgEAAgDACg");
	this.shape_30.setTransform(69.2,118.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#002179").s().p("AASA1IAAg3IgBgLQgBgFgCgCQgDgDgDgCQgDgBgFgBIgHABQgDACgCADQgCACgCAFIgBALIAAA4IgcAAIAAhnIAcAAIAAAGQAEgEAGgCQAHgDAGAAQALAAAHAEQAHADAFAHQAEAGADAIQACAJAAAMIAAA5g");
	this.shape_31.setTransform(58.8,116.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#002179").s().p("AgSAyQgJgEgGgGQgGgIgEgKQgDgKAAgMQAAgLADgKQAEgKAGgIQAGgHAJgDQAJgFAJAAQAKAAAJAFQAJADAGAHQAGAIAEAKQAEAKAAALQAAAMgEAKQgEAKgGAIQgGAGgJAEQgJAEgKAAQgJAAgJgEgAgIgZQgDACgCAEIgFAJIgBAKIABAMQACAFADADQACAEADACQAEACAEAAQAEAAAEgDQAEgCADgDQACgEABgFIABgLIgBgKIgDgJQgDgEgEgCQgEgCgEAAQgEAAgEACg");
	this.shape_32.setTransform(48,116.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#002179").s().p("AgNBJIAAiDIAbgOIAACRg");
	this.shape_33.setTransform(40.2,114.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#002179").s().p("AgSAyQgIgEgHgGQgGgIgEgKQgDgKgBgMQABgLADgKQAEgKAGgIQAHgHAIgDQAJgFAJAAQAKAAAJAFQAJADAGAHQAHAIADAKQAEAKAAALQAAAMgEAKQgDAKgHAIQgGAGgJAEQgJAEgKAAQgJAAgJgEgAgIgZQgEACgBAEIgFAJIgBAKIABAMQACAFADADQABAEAEACQAEACAEAAQAEAAAEgDQAEgCADgDQACgEABgFIACgLIgCgKIgDgJQgDgEgEgCQgEgCgEAAQgEAAgEACg");
	this.shape_34.setTransform(26.9,116.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#002179").s().p("AAABIQgFgDgEgDQgEgFgCgFQgCgHAAgHIAAgwIgSAAIAAgaIASAAIAAgbIAagOIAAApIAaAAIAAAaIgaAAIAAApQAAAIADACQADADAFAAQADAAAEgCIAIgGIgDAcIgJAFQgHABgGAAQgGAAgEgCg");
	this.shape_35.setTransform(17.6,115);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#002179").s().p("AASBJIAAg5IgBgLQgBgEgDgDQgBgCgDgCIgJgBIgGABQgEABgDADQgCACgBAEIgBALIAAA6IgbAAIAAiDIAbgOIAAAwQADgEAHgDQAHgCAGAAQAKAAAIADQAHADAFAHQAFAGACAJQACAHABAMIAAA7g");
	this.shape_36.setTransform(237.8,88.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#002179").s().p("AAABIQgFgDgEgEQgEgEgCgFQgCgGAAgHIAAgxIgSAAIAAgaIASAAIAAgbIAagOIAAApIAaAAIAAAaIgaAAIAAApQAAAIADACQADADAFAAQADAAAEgCIAJgGIgEAcIgJAFQgHABgGAAQgGAAgEgCg");
	this.shape_37.setTransform(227.8,89);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#002179").s().p("AgUA0QgHgCgFgEQgGgGgDgGQgDgIAAgJQAAgIADgHQADgGAGgEQAGgEAIgCQAHgCAJAAQAJAAAKADIAAgFQAAgGgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKgBQAKABAIACQAIACAFAFQAGAEADAIQADAGAAAJIAABFIgcAAIAAgGQgDAEgGACQgHADgGAAQgIgBgHgCgAgNAHQgEAEAAAGQAAAHAEADQAEAEAIAAQAGAAAFgCQAFgDACgEIAAgOQgDgCgEgBIgLgBQgIAAgEADg");
	this.shape_38.setTransform(218.6,90.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#002179").s().p("AgshGIAbAAIAAAHIAKgHQAGgCAFAAQAJAAAHADQAIAEAFAGQAGAHADALQADAPAAAKQAAAMgDAJQgCAJgGAIQgFAHgHADQgIAEgKAAQgFAAgGgCQgGgCgEgEIAAAfIgbAOgAgJgsQgEACgEAFIAAAmQAEAFAEACQAFACAFAAQAEAAADgBQADgCACgDIADgIIABgLIgBgOIgDgJIgGgGQgDgCgEAAQgFAAgEACg");
	this.shape_39.setTransform(208.6,92.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#002179").s().p("AAABIQgGgDgDgEQgEgEgCgFQgCgGAAgHIAAgxIgSAAIAAgaIASAAIAAgbIAagOIAAApIAaAAIAAAaIgaAAIAAApQAAAIADACQACADAGAAQADAAAEgCIAJgGIgFAcIgJAFQgGABgGAAQgGAAgEgCg");
	this.shape_40.setTransform(193,89);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#002179").s().p("AgXAyQgHgCgFgHQgEgGgDgIQgCgKAAgMIAAg5IAbAAIAAA3IABALQABAFACADQACADAEABQADACAEAAQAEAAAEgCQADgCACgCQADgDABgFIABgKIAAg4IAcAAIAABnIgcAAIAAgGQgEAEgGACQgHADgHAAQgJgBgIgDg");
	this.shape_41.setTransform(183.7,91);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#002179").s().p("AgPAyQgJgEgGgGQgIgIgDgKQgEgKAAgMQAAgLAEgKQAEgKAGgIQAHgGAJgEQAKgEAKgBIAMACQAGABAFADIAJAIIAJAJIgSATQgGgHgEgEQgGgEgIAAQgEAAgEACQgEACgDADQgDAFgCAEQgBAGAAAFQAAAGABAGQACAEADAFQADADAEACQAEACAEAAQAIAAAGgEQAEgCAGgIIASARQgLANgGAEIgLAFQgHACgIAAQgJgBgJgEg");
	this.shape_42.setTransform(173.3,90.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#002179").s().p("AgcAOIAAgbIA5AAIAAAbg");
	this.shape_43.setTransform(164.5,88.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#002179").s().p("AghA1IAAhnIAbAAIAAAGQAEgEAEgCQAGgDAHAAQAGABAGACQAEACADACIgHAbIgHgEQgFgCgEAAQgFAAgDACQgDABgCACIgDAIIgBAJIAAA4g");
	this.shape_44.setTransform(157.1,90.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#002179").s().p("AgUA0QgHgCgFgEQgGgGgDgGQgDgIAAgJQAAgIADgHQADgGAGgEQAGgEAIgCQAHgCAJAAQAJAAAKADIAAgFQAAgGgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKgBQAKABAIACQAIACAFAFQAGAEADAIQADAGAAAJIAABFIgcAAIAAgGQgDAEgGACQgHADgGAAQgIgBgHgCgAgNAHQgEAEAAAGQAAAHAEADQAEAEAIAAQAGAAAFgCQAFgDACgEIAAgOQgDgCgEgBIgLgBQgIAAgEADg");
	this.shape_45.setTransform(147.2,90.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#002179").s().p("AgHA1QgFgBgFgCQgJgEgGgHQgGgHgDgJQgDgLAAgMQAAgLADgKQADgKAHgIQAGgGAJgEQAIgEAJgBQALABAIAEQAIAEAGAHQAFAIAEAKQADAKAAAKIgBAJIg+AAQABAFABAEIAGAGQAFAFAIAAQAFAAAFgDQAFgCADgCIAUAQIgIAHIgJAFQgOAEgHABIgLgCgAATgLQgBgIgFgFIgFgEQgDgBgFgBQgHABgEAFQgEAFgCAIIAkAAIAAAAg");
	this.shape_46.setTransform(137.2,90.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#002179").s().p("AgNBJIAAiDIAbgOIAACRg");
	this.shape_47.setTransform(129.7,88.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#002179").s().p("AgPAyQgJgEgHgGQgGgIgEgKQgEgKAAgMQAAgLAEgKQADgKAHgIQAHgGAJgEQAKgEAJgBIANACQAGABAFADIAKAIIAIAJIgSATQgFgHgFgEQgHgEgHAAQgEAAgEACQgEACgDADQgDAFgBAEQgCAGAAAFQAAAGACAGQABAEADAFQADADAEACQAEACAEAAQAHAAAHgEQAEgCAHgIIARARQgKANgHAEIgLAFQgHACgIAAQgJgBgJgEg");
	this.shape_48.setTransform(122.2,90.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#002179").s().p("AgUA0QgHgCgFgEQgGgGgDgGQgDgIAAgJQAAgIADgHQADgGAGgEQAGgEAIgCQAHgCAJAAQAJAAAKADIAAgFQAAgGgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKgBQAKABAIACQAIACAFAFQAGAEADAIQADAGAAAJIAABFIgcAAIAAgGQgDAEgGACQgHADgGAAQgIgBgHgCgAgNAHQgEAEAAAGQAAAHAEADQAEAEAIAAQAGAAAFgCQAFgDACgEIAAgOQgDgCgEgBIgLgBQgIAAgEADg");
	this.shape_49.setTransform(106,90.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#002179").s().p("AgHA1QgGgBgEgCQgIgEgHgHQgGgHgDgJQgDgLgBgMQABgLADgKQADgKAHgIQAHgGAIgEQAJgEAIgBQAKABAJAEQAIAEAGAHQAGAIADAKQACAKAAAKIAAAJIg+AAQAAAFADAEIAEAGQAHAFAHAAQAGAAAEgDQAFgCADgCIAUAQIgIAHIgJAFQgOAEgHABIgLgCgAASgLQgBgIgDgFIgGgEQgEgBgEgBQgGABgFAFQgFAFgBAIIAjAAIAAAAg");
	this.shape_50.setTransform(90.3,90.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#002179").s().p("AAQBJIgUgxIgNARIAAAgIgbAAIAAiDIAbgOIAABMIAbgjIAhAAIgbAhIAdBHg");
	this.shape_51.setTransform(81,88.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#002179").s().p("AgUA0QgHgCgFgEQgGgGgDgGQgDgIAAgJQAAgIADgHQADgGAGgEQAGgEAIgCQAHgCAJAAQAJAAAKADIAAgFQAAgGgDgDQgEgEgIAAQgIAAgGABQgGACgHAEIgLgTQAKgGAJgCQAJgCAKgBQAKABAIACQAIACAFAFQAGAEADAIQADAGAAAJIAABFIgcAAIAAgGQgDAEgGACQgHADgGAAQgIgBgHgCgAgNAHQgEAEAAAGQAAAHAEADQAEAEAIAAQAGAAAFgCQAFgDACgEIAAgOQgDgCgEgBIgLgBQgIAAgEADg");
	this.shape_52.setTransform(69.9,90.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#002179").s().p("AgNBGIAAhwIgoAAIAAgbIBrAAIAAAbIgoAAIAABwg");
	this.shape_53.setTransform(61.2,89.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},39).to({state:[{t:this.instance_3}]},8).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]},135).wait(114));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({alpha:1},8).to({_off:true},135).wait(114));

	// Layer 12
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_54.setTransform(150.6,124.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_54).wait(296));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,124.1,301,251);
// library properties:
lib.properties = {
	id: 'C6253F227E274E66A891718B49578AB3',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/InvescoDistributorsInc.png?1527105018646", id:"InvescoDistributorsInc"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C6253F227E274E66A891718B49578AB3'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;